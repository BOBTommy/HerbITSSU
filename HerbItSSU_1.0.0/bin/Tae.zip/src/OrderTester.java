
public class OrderTester {
	static OrderSystem os;
	public static void main(String args[] )
	{
		os = new OrderSystem();
	}
}
