import javax.swing.JPanel;


class StorePanel extends JPanel{
	OrderSystem os;
	public StorePanel(OrderSystem os) {
		this.os = os;
		
	}
	public void dataUpdate() {
		
		
	}
}
