import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.CategoryToPieDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.util.TableOrder;

/*���� �Ǹŷ��� �׸��� ����Ʈ */
class HistogramChart{
	  private XYSeries series = null;
	  private XYDataset dataset = null;
	  private JFreeChart chart = null;
	  private TextTitle subTitle = null;
	  String menu;
	  public HistogramChart(){
		  menu = "Cafe Latte";
		  
		  series = new XYSeries(menu);
		  /* add�� ù��° ����: ��, �ι�° ����: �Ǹŷ� */
		  series.add(1, 10);
		  series.add(3, 11);
		  series.add(7, 12);
		  series.add(12, 14);
		  
	  }
	  public ChartPanel getHistogramChart_HistogramChart(){
	   ChartPanel chartPanel_HistogramChart = null;
	   dataset = new XYSeriesCollection(series);
	   chart = ChartFactory.createXYBarChart("Sales Monitoring", "Date", false, "Sale", (IntervalXYDataset) dataset, org.jfree.chart.plot.PlotOrientation.VERTICAL, true, true, false);
	   subTitle = new TextTitle("���� ������Ȳ");
	   chart.setBorderVisible(false);
	   
	   
	   
	   chart.setBackgroundPaint(Color.WHITE);
	   chart.addSubtitle(subTitle);
	   chartPanel_HistogramChart = new ChartPanel(chart);
	   return chartPanel_HistogramChart;
	  }
}

/*�޴��� �Ǹŷ��� �׸��� ������Ʈ */
class PieChart{
	  private JFreeChart chart = null;
	  private TextTitle subTitle = null;
	  private String menuList[] = {				//��ư�� �� �޴���
				"coffee1", "coffee2", "coffee3", "coffee4", "coffee5", "coffee6", "coffee7", "coffee8", "coffee9"
				, "coffee10", "coffee11", "coffee12", "coffee13", "coffee14", "coffee15", "coffee16", "coffee17", 
				"coffee18", "coffee19", "coffee20"
		};
	  private DefaultCategoryDataset myDataset;
	  public PieChart(){
		  myDataset = new DefaultCategoryDataset();
		  
		  /* �Ǹŷ��� �޴��� ���� �κ� */ 
		  myDataset.setValue(10, "", menuList[0]);
		  myDataset.setValue(50, "", menuList[13]);
	  }
	  public ChartPanel getPieChart_HistogramChart(){
	   ChartPanel chartPanel_PieChart = null;
	   
	   chart = ChartFactory.createPieChart("Sales Monitoring", new CategoryToPieDataset(myDataset, TableOrder.BY_ROW, 0), true, true, false);
	   subTitle = new TextTitle("���� ������Ȳ");
	   chart.setBorderVisible(false);
	   chart.setBackgroundPaint(Color.WHITE);
	   chart.addSubtitle(subTitle);
	   chartPanel_PieChart = new ChartPanel(chart);
	   return chartPanel_PieChart;
	  }
}


class AdminPanel extends JPanel {
	
	OrderSystem os;
	
	private JTable adminTable;
	private DefaultTableModel adminTableModel;
	private JScrollPane adminTableScroll;
	private JScrollPane barScroll, pieScroll;
	private JScrollPane rightScroll;
	private String data[][] = new String[15][4];		//�ֹ��� ����� �����ͼ�, 30�� 4��
	private String columnNames[] = { "�޴���", "�Ⱓ�� �Ǹż���", "�ܰ�", "�����" };
	private JPanel leftPanel;				/* �׷����� ���̺��� ������ �г� */	
	private JPanel rightPanel;				/* ��ư�� ������ �г� */
	private JPanel barPanel, piePanel;				/* �׷����� ��� �г� */
	private JButton pie, bar, table;
	
	public AdminPanel( OrderSystem os ) {
		this.os = os;
		
		
		/* ���̺� ���̾ƿ� ���� ���� */
		adminTable = new JTable();
		adminTableModel = new DefaultTableModel(data, columnNames);
		adminTable.setModel(adminTableModel);
		
		adminTableScroll = new JScrollPane(adminTable);
		adminTableScroll
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		adminTableScroll
				.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		adminTableModel.setDataVector(data, columnNames);
		/* ���̺� ���̾ƿ� ���� �� */
		
		this.setLayout(new BorderLayout());
		leftPanel = new JPanel();
		rightPanel = new JPanel();
		this.add(leftPanel, BorderLayout.CENTER);
		
		
		leftPanel.setLayout( new BorderLayout() );
		rightPanel.setLayout( new ModifiedFlowLayout() );
		rightScroll = new JScrollPane(rightPanel);
		this.add(rightScroll, BorderLayout.EAST);
		/* �׷��� ����  ���� */
		barPanel = new JPanel(new ModifiedFlowLayout() );
		barScroll = new JScrollPane(barPanel);
		
		piePanel = new JPanel(new ModifiedFlowLayout() );
		pieScroll = new JScrollPane(piePanel);
		//graphPanel.add(new JButton("�׷���"));
		//JFreeChart pieChart = new JFreeChart();
		HistogramChart barC = new HistogramChart();
		barPanel.add(barC.getHistogramChart_HistogramChart());
		
		PieChart pieC = new PieChart();
		piePanel.add(pieC.getPieChart_HistogramChart());
		/* �׷��� ���� �� */
		
		
		/* �����гο� ���Ҵޱ� */
		
		leftPanel.add(barScroll, BorderLayout.CENTER);
		
		
		//leftPanel.add(adminTableScroll, BorderLayout.SOUTH);
		//leftPanel.remove(adminTableScroll);
		
		
		
		/* �����гο� ��ư �ޱ� */
		pie = new JButton("pie");
		pie.addActionListener( new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				/* DB test */
				DBGenerator testDB = new DBGenerator();
				testDB.insert_query(
						"insert herb_menu(" +
						"menu_id," +
						" menu_name," +
						" menu_price," +
						" menu_reg_date" +
						") " +
						"values(" +
						" 1," +
						" 'ī���', " +
						"4500, " +
						"now())");
				/* DB test*/
				leftPanel.removeAll();
				leftPanel.add(pieScroll, BorderLayout.CENTER);
				leftPanel.setVisible(false);
				leftPanel.setVisible(true);
			}
		});
		
		bar = new JButton("bar");
		bar.addActionListener (new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/* DB test */
				DBGenerator testDB = new DBGenerator();
				testDB.printAll_HerbMenuTable();
				/* DB test*/
				leftPanel.removeAll();
				leftPanel.add(barScroll, BorderLayout.CENTER);
				leftPanel.setVisible(false);
				leftPanel.setVisible(true);
			}
		});
		
		table = new JButton("table");
		table.addActionListener (new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				leftPanel.removeAll();
				leftPanel.add(adminTableScroll, BorderLayout.CENTER);
				leftPanel.setVisible(false);
				leftPanel.setVisible(true);
				
			}
		});
		rightPanel.add(pie);
		rightPanel.add(bar);
		rightPanel.add(table);
	}
	public void dataUpdate() {			//������ ����Ǿ���� �κ�
		
		
	}
	
}
