import java.util.Date;




class HerbMenuTable {
	private int id_menu;
    private int menu_id;
    private String menu_name;
    private int  menu_price;
    private Date menu_reg_date;
	public int getId_menu() {
		return id_menu;
	}
	public void setId_menu(int id_menu) {
		this.id_menu = id_menu;
	}
	public int getMenu_id() {
		return menu_id;
	}
	public void setMenu_id(int menu_id) {
		this.menu_id = menu_id;
	}
	public String getMenu_name() {
		return menu_name;
	}
	public void setMenu_name(String menu_name) {
		this.menu_name = menu_name;
	}
	public int getMenu_price() {
		return menu_price;
	}
	public void setMenu_price(int menu_price) {
		this.menu_price = menu_price;
	}
	public Date getMenu_reg_date() {
		return menu_reg_date;
	}
	public void setMenu_reg_date(Date date) {
		this.menu_reg_date = date;
	}
    public String toString() { 
    	String result = null;
    	result = id_menu + "|";
        result += menu_id + "|";
        result += menu_name + "|";
        result += menu_price + "|";
        result += menu_reg_date ;
        return result;
    }
}
