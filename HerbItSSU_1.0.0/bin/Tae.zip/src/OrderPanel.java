import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.event.*;
class PopupFrame extends JFrame implements ActionListener
{
	public PopupFrame(String title, String label){
		super(title);
		this.setLayout(new BorderLayout());
		this.setSize(400,300);
		
		//â�ݱ� ��ư Ŭ���� ������ ����
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		//��ư����
		JButton btn = new JButton("Ȯ��");
		btn.addActionListener(this);

		//�����ӿ� �߰�
		this.add("Center",new JLabel(label,JLabel.CENTER));
		this.add("South",btn);

		//â���̱�
		this.setVisible(true);
	}

	//�������̵�
	public void actionPerformed(ActionEvent ae){
		
		this.setVisible(false);
		this.dispose();
	}
}


/**
 * JPanel�� FlowLayout������ ScrollPane�� �� ��� ����ε� ������ �ϵ��� ����� ModifiedFlowLayout 
 * A modified version of FlowLayout that allows containers using this
 * Layout to behave in a reasonable manner when placed inside a
 * JScrollPane

 * @author Babu Kalakrishnan
 * Modifications by greearb and jzd
 */

class ModifiedFlowLayout extends FlowLayout {
      public ModifiedFlowLayout() {
             super();
          }

          public ModifiedFlowLayout(int align) {
             super(align);
          }
      public ModifiedFlowLayout(int align, int hgap, int vgap) {
         super(align, hgap, vgap);
      }

      public Dimension minimumLayoutSize(Container target) {
         // Size of largest component, so we can resize it in
         // either direction with something like a split-pane.
         return computeMinSize(target);
      }

      public Dimension preferredLayoutSize(Container target) {
         return computeSize(target);
      }

      private Dimension computeSize(Container target) {
         synchronized (target.getTreeLock()) {
            int hgap = getHgap();
            int vgap = getVgap();
            int w = target.getWidth();

            // Let this behave like a regular FlowLayout (single row)
            // if the container hasn't been assigned any size yet
            if (w == 0) {
               w = Integer.MAX_VALUE;
            }

            Insets insets = target.getInsets();
            if (insets == null){
               insets = new Insets(0, 0, 0, 0);
            }
            int reqdWidth = 0;

            int maxwidth = w - (insets.left + insets.right + hgap * 2);
            int n = target.getComponentCount();
            int x = 0;
            int y = insets.top + vgap; // FlowLayout starts by adding vgap, so do that here too.
            int rowHeight = 0;

            for (int i = 0; i < n; i++) {
               Component c = target.getComponent(i);
               if (c.isVisible()) {
                  Dimension d = c.getPreferredSize();
                  if ((x == 0) || ((x + d.width) <= maxwidth)) {
                     // fits in current row.
                     if (x > 0) {
                        x += hgap;
                     }
                     x += d.width;
                     rowHeight = Math.max(rowHeight, d.height);
                  }
                  else {
                     // Start of new row
                     x = d.width;
                     y += vgap + rowHeight;
                     rowHeight = d.height;
                  }
                  reqdWidth = Math.max(reqdWidth, x);
               }
            }
            y += rowHeight;
            y += insets.bottom;
            return new Dimension(reqdWidth+insets.left+insets.right, y);
         }
      }

      private Dimension computeMinSize(Container target) {
         synchronized (target.getTreeLock()) {
            int minx = Integer.MAX_VALUE;
            int miny = Integer.MIN_VALUE;
            boolean found_one = false;
            int n = target.getComponentCount();

            for (int i = 0; i < n; i++) {
               Component c = target.getComponent(i);
               if (c.isVisible()) {
                  found_one = true;
                  Dimension d = c.getPreferredSize();
                  minx = Math.min(minx, d.width);
                  miny = Math.min(miny, d.height);
               }
            }
            if (found_one) {
               return new Dimension(minx, miny);
            }
            return new Dimension(0, 0);
         }
      }

  }



class OrderPanel extends JPanel {
	
	class menuListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			JButton tmp1 = (JButton)e.getSource();
			String name = tmp1.getText();
			
			String price = "0";
			int numberOfItem =0 , sumOfEachItemPrice =0 ;		//�ܰ�, �޴��� �հ�
			/* �ݺ��ϸ� ������ �޾ƿ´�. */
			for (int tmp=0; tmp<menuList.length; tmp++ ) {
				if (menuList[tmp].compareTo(name)==0)
				{
					price = priceList[tmp];
				}
			}
			/* �ݺ��ϸ� ������ �޴��� �հ踦 �޾ƿ´�. */
			boolean sameMenuPickFlag = false;
			int pos = currentNumber;
			for (int tmp=0; tmp<currentNumber; tmp++) {
				if (name.compareTo(data[tmp][0])==0) {
					numberOfItem = Integer.valueOf(data[tmp][1]).intValue()
							+ 1;
					sumOfEachItemPrice = Integer.valueOf(data[tmp][3]).intValue()
							+ Integer.valueOf(price).intValue();
					pos = tmp;
					sameMenuPickFlag = true;
				}
			}
			if (sameMenuPickFlag == false) {
				numberOfItem = 1;
				sumOfEachItemPrice = Integer.valueOf(price).intValue();
				currentNumber ++;
			}
			/* �޾ƿ��� �� */
			/* ���̺��� ���� */
			/* data[][0]: �޴���, data[][1]: �ֹ�����, data[][2]: �ܰ�, data[][3]: �޴��ֹ��������հ�*/
			data[pos][0] = name;
			data[pos][1] = Integer.toString(numberOfItem);
			data[pos][2] = price;
			data[pos][3] = Integer.toString(sumOfEachItemPrice);
			
			orderListTableModel.setDataVector(data, columnNames);
			
			
		}	
	}
	
	OrderSystem os;
	
	private JTable orderListTable;
	private DefaultTableModel orderListTableModel;
	private JScrollPane orderListTableScroll;
	private String data[][] = new String[30][4];		//�ֹ��� ����� �����ͼ�, 30�� 4��
	int currentNumber = 0;							//�ֹ����� �޴� ��
	final int maximumNumber = 60; 						//�� ���� �� �ֹ������� �޴� ��	
	private String menuList[] = {				//��ư�� �� �޴���
			"Ŀ��1", "Ŀ��2", "Ŀ��3", "Ŀ��4", "Ŀ��5", "Ŀ��6", "Ŀ��7", "Ŀ��8", "Ŀ��9"
			,"Ŀ��10", "Ŀ��11", "Ŀ��12", "Ŀ��13", "Ŀ��14", "Ŀ��15", "Ŀ��16", "Ŀ��17", "Ŀ��18", "Ŀ��19", "Ŀ��20"
	};
	private JScrollPane menuListScroll;
	private String priceList[] = {
			"1100", "1200", "1300", "1400", "1500", "1600", "1700", "1800", "1900",
			"2000", "2100", "2200", "2300", "2400", "2500", "2600", "2700", "2800", "2900", "3000"
	};
	private JButton menuBtn[] = new JButton[menuList.length];
	JButton cash, card, cancel;
	private String columnNames[] = { "�޴���", "����", "�ܰ�", "�޴��� �հ�"};
	/* data[][0]: �޴���, data[][1]: �ֹ�����, data[][2]: �ܰ�, data[][3]: �޴��ֹ��������հ�*/
	private JPanel leftPanel;					//PIXEL ����
	private JPanel cardCash;					//��ư�ΰ��� �г�
	
	
	public OrderPanel( OrderSystem os ) {
		this.os = os;
		
		
		/* ���̺� ���̾ƿ� ���� ���� */
		orderListTable = new JTable();
		orderListTableModel = new DefaultTableModel(data, columnNames);
		orderListTable.setModel(orderListTableModel);
		
		orderListTableScroll = new JScrollPane(orderListTable);
		orderListTableScroll
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		orderListTableScroll
				.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		/* ���̺� ���̾ƿ� ���� �� */
		this.setLayout(new BorderLayout());
		this.add(orderListTableScroll, BorderLayout.EAST);
		leftPanel = new JPanel();
		cardCash = new JPanel();
		this.add(cardCash, BorderLayout.SOUTH);
		/* �ȼ��۾� �ʿ��Ѻκ� ���� PIXEL*/
		leftPanel.setLayout( new ModifiedFlowLayout() );
		cardCash.setLayout(new FlowLayout());
		/* �ȼ��۾� �ʿ��Ѻκ� �� PIXEL*/
		
		menuListScroll = new JScrollPane(leftPanel);
		menuListScroll
			.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		menuListScroll
			.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		this.add(menuListScroll, BorderLayout.CENTER);
		for( int tmp=0; tmp<menuList.length; tmp++)
		{
			menuBtn[tmp] = new JButton(menuList[tmp]);
			menuBtn[tmp].addActionListener(new menuListener());
			/* �ȼ��۾� �ʿ��� �κ� 2 */
			leftPanel.add(menuBtn[tmp]);
			/* �ȼ��۾� �ʿ��Ѻκ� 2�� */
		}
		/*�ȼ��۾� �ʿ��� �κ� 3 */
		cash = new JButton("����");
		cash.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new PopupFrame("����", "���ݰ��");
				
			}
		});
		cardCash.add(cash);
		card = new JButton("ī��");
		card.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				new PopupFrame("ī��", "ī����");
			}
			
		});
		cardCash.add(card);
		cancel = new JButton("���");
		cancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				for(int x=0 ; x < data.length ; x++) {
					data[x][0] = "";
					data[x][1] = "";
					data[x][2] = "";
					data[x][3] = "";
				}
				currentNumber=0;
				orderListTableModel.setDataVector(data, columnNames);
			}
			
		});
		cardCash.add(cancel);
		/* �ȼ��۾� �ʿ��� �κ� 3 ��*/
		
		orderListTableModel.setDataVector(data, columnNames);
		
	}
	public void dataUpdate() {			//������ ����Ǿ���� �κ�
		
		
	}
	
}
