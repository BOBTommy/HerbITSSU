import java.sql.Connection;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;


class DBGenerator {
	
		 
	    static String jdbcUrl = "jdbc:mysql://localhost:3306/herb";// ����ϴ� �����ͺ��̽����� ������ url
	    static String userId = "root";// ����ڰ���
	    static String userPass = "ssuherb";// ����� �н�����
	 
	    public void printAll_HerbMenuTable() {
	        try {
	            Class.forName("com.mysql.jdbc.Driver");// ����̹� �ε�: DriverManager�� ���
	        } catch (ClassNotFoundException e) {
	            System.err.print("ClassNotFoundException: ");
	        }
	        Connection conn = null;
	        java.sql.Statement stmt = null;
	        java.sql.ResultSet rs = null;
	        try {
	 
	            conn = java.sql.DriverManager.getConnection(jdbcUrl, userId, userPass);// Connection ��ü�� ��
	 
	            stmt = conn.createStatement();// Statement ��ü�� ��
	 
	            StringBuffer sb = new StringBuffer();

	            sb.append("select * from herb_menu\n");
	            
	            rs = stmt.executeQuery(sb.toString());
	            HerbMenuTable obj = new HerbMenuTable();
	            while (rs.next()) {
	                obj.setId_menu(rs.getInt("id_menu"));
	                obj.setMenu_id(rs.getInt("menu_id"));
	                obj.setMenu_name(rs.getString("menu_name"));
	                obj.setMenu_price(rs.getInt("menu_price"));
	                /* ��¥ ����Ͽ� date������ �о���� */
	                String DATE_FORMAT = "yyyy-MM-dd kk:mm:ss";
	                SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT); 
	                obj.setMenu_reg_date(format.parse(rs.getString("menu_reg_date"), new ParsePosition(0)));
	                /* print */
	                System.out.println(obj);
	                /* print */
	            }
	 
	        } catch (java.sql.SQLException e) {
	            System.out.println("SQLException: " + e.getMessage());
	            e.printStackTrace();
	        } catch (Exception e) {
	        	e.printStackTrace();
	        }
	        finally {
	            try {
	                rs.close();
	                stmt.close();
	                conn.close();
	            } catch (java.sql.SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	    public boolean insert_query(String query) {
	    	boolean res = false;
	        try {
	            Class.forName("com.mysql.jdbc.Driver");// ����̹� �ε�: DriverManager�� ���
	        } catch (ClassNotFoundException e) {
	            System.err.print("ClassNotFoundException: ");
	        }
	        Connection conn = null;
	        java.sql.Statement stmt = null;
	        java.sql.ResultSet rs = null;
	        try {
	 
	            conn = java.sql.DriverManager.getConnection(jdbcUrl, userId, userPass);// Connection ��ü�� ��
	 
	            stmt = conn.createStatement();// Statement ��ü�� ��
	 
	            StringBuffer sb = new StringBuffer();
	            System.out.println(query);
	            stmt.executeUpdate(query);
	            res = true;
	        } catch (java.sql.SQLException e) {
	            System.out.println("SQLException: " + e.getMessage());
	            e.printStackTrace();
	        } catch (Exception e) {
	        	e.printStackTrace();
	        }
	        finally {
	            try {
	                
	                stmt.close();
	                conn.close();
	            } catch (java.sql.SQLException e) {
	                e.printStackTrace();
	            }
	        }
	        return res;
	    }

}
